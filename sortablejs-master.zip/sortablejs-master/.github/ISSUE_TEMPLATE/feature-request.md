---
name: Feature request
about: Suggest an idea for this project
title: "[feature] "
labels: ""
assignees: ""
---

_**[PLEASE READ THE CONTRIBUTION GUIDELINES HERE!](https://github.com/SortableJS/Sortable/tree/master/CONTRIBUTING.md)**_

_Failure to comply may have your issue automatically closed._

## Summary

Please answer the following questions in sentences.

- What is the feature?
- Why is having this feature important to you?
- Who else will find having this feature helpful?

## Additional Context
