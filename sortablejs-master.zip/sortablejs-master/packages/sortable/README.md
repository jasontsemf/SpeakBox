# sortable

This is the primary class of sortablejs. This package is not the offical sortablejs, which can be found in packages/sortablejs.
